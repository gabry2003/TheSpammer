# TheSpammer

Estensione per browser che spamma messaggi su Whatsapp Web, Telegram Web e Google Meet.


## Install

	$ npm install

## Info. compilaion process
OS: Fedora 32
IDE: VS Code

node v12.18.3
npm 6.14.8

## Development

    npm run dev chrome
    npm run dev firefox
    npm run dev opera
    npm run dev edge

## Build

    # Oppure usa ./compile.sh
    npm run build chrome
    npm run build firefox
    npm run build opera
    npm run build edge

## Environment

The build tool also defines a variable named `process.env.NODE_ENV` in your scripts. 

## Docs

* [webextension-toolbox](https://github.com/HaNdTriX/webextension-toolbox)
