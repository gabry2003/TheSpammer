npm install
npm run buildAll
